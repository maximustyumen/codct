#ifndef INPUTHYDRACLASS
#define INPUTHYDRACLASS

#include <stdio.h>
#include <stdlib.h>
#include <osgViewer/Viewer>
#include "../../../Configure/Configure.h"

#include "../../../Scene/Visitors/FindNodeByName.h"

//��������� ����������� ������
#include "../../../error/errorclass.h"


#include "../../UserFoot.h"
#include "../../UserHands.h"


#include <sixense.h>
#include <sixense_math.hpp>
#ifdef WIN32
#include <sixense_utils/mouse_pointer.hpp>
#endif
#include <sixense_utils/derivatives.hpp>
#include <sixense_utils/button_states.hpp>
#include <sixense_utils/event_triggers.hpp>
#include <sixense_utils/controller_manager/controller_manager.hpp>

#include <deque>

#include "../../HydraDataClass.h"


//����� ������������ ����������
class InputHydraClass
{
public:
	InputHydraClass();
	void Update();

	//float x,y;
	//bool command;

	
	HydraData getHydraData() { return zz;}

private:
	void static controller_manager_setup_callback( sixenseUtils::ControllerManager::setup_step step ); 
	~InputHydraClass();
	HydraData zz;

	bool init;

	//0 - push
	//1 - pushed
	//2 - release
	//3 - relax
	int button3_prev_state;
	int button1_prev_state;
};




	
#endif