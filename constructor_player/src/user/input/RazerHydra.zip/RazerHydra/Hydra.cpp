/***************************************************************************
Hydra.cpp  -  стандартный интерфейс для Razor Hydra
-------------------
begin                : 6 февраля 2014
copyright            : (C) 2014 by Гаммер Максим Дмитриевич (maximum2000)
email                : MaxGammer@gmail.com
***************************************************************************/

#include "./Hydra.h"
#include <iostream>


//hemi_tracking_enabled;   ???

void InputHydraClass::controller_manager_setup_callback( sixenseUtils::ControllerManager::setup_step step ) {
	std::string controller_manager_text_string;
	if( sixenseUtils::getTheControllerManager()->isMenuVisible() ) {

		// Turn on the flag that tells the graphics system to draw the instruction screen instead of the controller information. The game
		// should be paused at this time.

		// Ask the controller manager what the next instruction string should be.
		controller_manager_text_string = sixenseUtils::getTheControllerManager()->getStepString();
		std::cout <<controller_manager_text_string << std::endl;
		// We could also load the supplied controllermanager textures using the filename: sixenseUtils::getTheControllerManager()->getTextureFileName();

	} else {

		// We're done with the setup, so hide the instruction screen.


	}

}

InputHydraClass::~InputHydraClass()
{
	if (init)
	{
		std::cout << "hydra exit ...";
		sixenseExit();
		std::cout << " OK" << std::endl;
	}
}


InputHydraClass::InputHydraClass()
{
	init = false;

	zz.presend = false;
	zz.angle0 = 0;
	zz.angle1 =0;
	zz.angle2 = 0;
	zz.button3 = 3;
	zz.dHeadX = 0;
	zz.dHeadY = 0;
	zz.footX = 0;
	zz.footY = 0;
	zz.pos0 = 0;
	zz.pos1 = 0;
	zz.pos2 = 0;

	button3_prev_state=3;
	button1_prev_state=3;

	std::cout << std::endl << "\tHandsHydraClass constructor ... " <<std::endl;
	
	// Init sixense
	std::cout << "\tHydra init...";

	if (sixenseInit() != SIXENSE_SUCCESS)
	{
		std::cout << " sixenseInit() FAILED..." << std::endl;
		return;
	}
	//немного подождем....
	osg::Timer_t tick1 = osg::Timer::instance()->tick();
	while ( osg::Timer::instance()->delta_s(tick1,osg::Timer::instance()->tick())<1)
	{
	}

	if (sixenseIsBaseConnected(0)==0)
	{
		std::cout << " sixenseIsBaseConnected(0) 0" << std::endl;
		sixenseExit();
		return;
	}

	std::cout << " OK." << std::endl;
	init = true;
	zz.presend = true;

	// Init the controller manager. This makes sure the controllers are present, assigned to left and right hands, and that
	// the hemisphere calibration is complete.
	sixenseUtils::getTheControllerManager()->setGameType( sixenseUtils::ControllerManager::ONE_PLAYER_TWO_CONTROLLER );
	sixenseUtils::getTheControllerManager()->registerSetupCallback( controller_manager_setup_callback );
}

#define _180_PI 57.324840764331210191082802547771
float radToDeg(float r) {
    return r * _180_PI;
}

void InputHydraClass::Update()
{
	if (init==false) return;

	float angles[3] = {0,0,0};
	float pos[3];

	sixenseAllControllerData acd;
	for(int base=0; base < sixenseGetMaxBases(); base++) 
	{
		sixenseSetActiveBase(base);
		sixenseGetAllNewestData(&acd);
		for(int cont=0; cont < sixenseGetMaxControllers(); cont++ ) 
		{


			if(sixenseIsControllerEnabled(cont) && cont == 0)
			{
				zz.dHeadX = acd.controllers[cont].joystick_x;
				zz.dHeadY = acd.controllers[cont].joystick_y ;

				//рычаг газа) 0..1
				zz.zoom = acd.controllers[cont].trigger;
			}

			if(sixenseIsControllerEnabled(cont) && cont == 1)
			{
				zz.zoom2 = acd.controllers[cont].trigger;
			}
			

			if(sixenseIsControllerEnabled(cont) && cont == 1)
			{
				//клавиши
				//джойстики -1...0...1
				zz.footX = acd.controllers[cont].joystick_x;
				zz.footY = acd.controllers[cont].joystick_y ;

				if (acd.controllers[cont].buttons & SIXENSE_BUTTON_BUMPER) std::cout << "SIXENSE_BUTTON_BUMPER"  << std::endl;
				if (acd.controllers[cont].buttons & SIXENSE_BUTTON_JOYSTICK) std::cout << "SIXENSE_BUTTON_JOYSTICK"  << std::endl;
				if (acd.controllers[cont].buttons & SIXENSE_BUTTON_1) std::cout << "SIXENSE_BUTTON_1"  << std::endl;
				if (acd.controllers[cont].buttons & SIXENSE_BUTTON_2) std::cout << "SIXENSE_BUTTON_2"  << std::endl;
				
				if (acd.controllers[cont].buttons & SIXENSE_BUTTON_3) 
				{
					if (button3_prev_state==0) button3_prev_state = 1; 
					if (button3_prev_state==3) button3_prev_state = 0;
				}
				else
				{
					if (button3_prev_state==2) button3_prev_state = 3;
					if ((button3_prev_state==0)||(button3_prev_state==1)) button3_prev_state = 2;	
						
				}
				zz.button3 = button3_prev_state;

				if (acd.controllers[cont].buttons & SIXENSE_BUTTON_1) 
				{
					if (button1_prev_state==0) button1_prev_state = 1; 
					if (button1_prev_state==3) button1_prev_state = 0;
				}
				else
				{
					if (button1_prev_state==2) button1_prev_state = 3;
					if ((button1_prev_state==0)||(button1_prev_state==1)) button1_prev_state = 2;	
						
				}
				zz.button1 = button1_prev_state;

				if (acd.controllers[cont].buttons & SIXENSE_BUTTON_4) std::cout << "SIXENSE_BUTTON_4"  << std::endl;
				if (acd.controllers[cont].buttons & SIXENSE_BUTTON_START) std::cout << "SIXENSE_BUTTON_START"  << std::endl;
			}





			if(sixenseIsControllerEnabled(cont) ) 
			{
				float quat[4] = {0,0,0,0};
				
				quat[0] = acd.controllers[cont].rot_quat[0]; //x
				quat[1] = acd.controllers[cont].rot_quat[1]; //y
				quat[2] = acd.controllers[cont].rot_quat[2]; //z
				quat[3] = acd.controllers[cont].rot_quat[3]; //w

				// yaw
				angles[0] = radToDeg(atan2(2*quat[0]*quat[3]-2*quat[1]*quat[2], 1-2*pow(quat[0],2)-2*pow(quat[2],2)));
				// pitch
				angles[1] = radToDeg(atan2(2*quat[1]*quat[3]-2*quat[0]*quat[2], 1-2*pow(quat[1], 2)-2*pow(quat[2],2)));
				// roll
				angles[2] = radToDeg(asin(2*quat[0]*quat[1]+2*quat[2]*quat[3]));

				//
				pos[0]= acd.controllers[cont].pos[0]; 
				pos[1]= acd.controllers[cont].pos[1]; 
				pos[2]= acd.controllers[cont].pos[2]; 

				if (cont == 1)
				{
					zz.angle0 = angles[0];
					zz.angle1 = angles[1];
					zz.angle2 = angles[2];
					zz.pos0 = pos[0];
					zz.pos1 = pos[1];
					zz.pos2 = pos[2];
				}
				else
				{
					
					zz.left_angle0 = angles[0];
					zz.left_angle1 = angles[1];
					zz.left_angle2 = angles[2];
					zz.left_pos0 = pos[0];
					zz.left_pos1 = pos[1];
					zz.left_pos2 = pos[2];
				}

			}
		}
	}

}






/*
osg::Vec2d worldToScreen(const osg::Vec3d& worldPosition, const osg::Camera* pCamera) 
{ 
    osg::Vec2d screenPosition; 

    if (pCamera!= NULL) 
    { 
        osg::Matrixd MVPW = pCamera->getViewMatrix() * pCamera->getProjectionMatrix() * pCamera->getViewport()->computeWindowMatrix(); 

        osg::Vec4d screenPosition4d = osg::Vec4d(worldPosition, 1.0) * MVPW; 
        screenPosition4d = screenPosition4d / screenPosition4d.w(); 
        screenPosition4d.y() = pCamera->getViewport()->height() - screenPosition4d.y(); 

        screenPosition.set(screenPosition4d.x(), screenPosition4d.y()); 
    } 

    return screenPosition; 
} 
*/

/*
osg::Vec3d screenToWorld(const osg::Vec2d& screenPosition, const osg::Camera* pCamera) 
{ 
    osg::Vec3d worldPosition; 

    if (pCamera!= NULL) 
    { 
        osg::Vec4 screenPositionNear(screenPosition.x(), pCamera->getViewport()->height() - screenPosition.y(), 0.0, 1.0); 

        osg::Vec4 screenPositionFar(screenPosition.x(), pCamera->getViewport()->height() - screenPosition.y(), 1.0, 1.0); 

        osg::Matrixd iMVPW = osg::Matrixd::inverse(pCamera->getViewMatrix() * pCamera->getProjectionMatrix() * pCamera->getViewport()->computeWindowMatrix()); 

        osg::Vec4 worldPositionNear = screenPositionNear * iMVPW; 
        osg::Vec4 worldPositionFar = screenPositionFar * iMVPW; 

        worldPositionNear = worldPositionNear / worldPositionNear.w(); 
        worldPositionFar = worldPositionFar / worldPositionFar.w(); 


        worldPosition.set((worldPositionNear.x() + worldPositionFar.x())/2.0, (worldPositionNear.y() + worldPositionFar.y())/2.0,  (worldPositionNear.z() + worldPositionFar.z())/2.0); 
    } 

    return worldPosition; 

} 
*/




