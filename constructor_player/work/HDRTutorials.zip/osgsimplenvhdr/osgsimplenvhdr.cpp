// -*-c++-*-

/*
 * demonstrates usage High Dynamic Range on NVIDIA FX hardware and up
 *
 * - essentially behaves like TextureRectangle, *except* that:
 * - tex internal format must be set to GL_FLOAT_RGBA16_NV or similar
 * - geometry need at last one simple shader to read the texture, like the follow:
 *       gl_FragColor = texture2DRect( tex0, gl_TexCoord[0].st );
 * - keyboard mapping:
 *       - and =, change the exposition
 *       9 and 0, increase and decrease the dynamic range
 *       7 and 8, increase and decrease the delta change
 *       g and G, toogle gray scale
 *
 */

#include <osg/Notify>
#include <osg/TextureRectangle>
#include <osg/Geometry>
#include <osg/Geode>

#include <osg/Group>
#include <osg/Projection>
#include <osg/MatrixTransform>
#include <osgText/Text>

#include <osgDB/Registry>
#include <osgDB/ReadFile>

#include <osgProducer/Viewer>

class Exposure
{
private:
    float index, range, delta;
    bool gray;
    osg::Uniform * umin;
    osg::Uniform * umax;
    osg::Uniform * ugray;

    void update()
    {
        float min, max;
        min = index - ( range / 2.0 );
        max = index + ( range / 2.0 );

        fprintf(stderr, "Exposure %f, Range %f, Delta %f, Dynamic Range (%f, %f)\n",
                index, range, delta, min, max );

        umin->set( min );
        umax->set( max );
    }

public:
    Exposure()
        : index( 0.5 ), range( 1.0 ), delta( 0.1 ), gray( false )
    {
        umin = new osg::Uniform( "min",  0.0f );
        umax = new osg::Uniform( "max",  0.0f );
        ugray = new osg::Uniform( "gray",  gray );
        update();
    }
   
    osg::Uniform * getUniformMin()
    {
        return umin;
    }
    osg::Uniform * getUniformMax()
    {
        return umax;
    }
    osg::Uniform * getUniformGrayScale()
    {
        return ugray;
    }
    
    void incIndex()
    {
        index += delta;
        update();
    }
    void decIndex()
    {
        index -= delta;
        update();
    }
    void incRange()
    {
        range += delta;
        update();
    }
    void decRange()
    {
        range -= delta;
        range = range < 0.0 ? 0.0 : range;
        update();
    }
    void incDelta()
    {
        delta += 0.01;
        update();
    }
    void decDelta()
    {
        delta -= 0.01;
        delta = delta < 0.0 ? 0.0 : delta;
        update();
    }
    void toogleGrayScale()
    {
        gray = !gray;
        ugray->set( gray );
    }
} exposure;
    
osg::Program * shader( std::string filename )
{
    
    osg::Shader* FragmentObject =
      new osg::Shader( osg::Shader::FRAGMENT );
    bool frag = FragmentObject->loadShaderSourceFromFile( filename );
            
    osg::Program* ProgramObject = new osg::Program;
    if (frag) ProgramObject->addShader( FragmentObject );

    return ProgramObject;
}

/**********************************************************************
 *
 * Texture pan animation callback
 *
 **********************************************************************/

class TexturePanCallback : public osg::NodeCallback
{
public:
    TexturePanCallback(osg::Geometry* geom, osg::Image* img,
                       double delay = 0.05) :
        _geom(geom),
        _img(img),
        _phaseS(35.0f),
        _phaseT(18.0f),
        _phaseScale(5.0f),
        _delay(delay),
        _prevTime(0.0)
    {
    }

    virtual void operator()(osg::Node*, osg::NodeVisitor* nv)
    {
        if (!_geom || !_img)
            return;

        if (nv->getFrameStamp()) {
            double currTime = nv->getFrameStamp()->getReferenceTime();
            if (currTime - _prevTime > _delay) {

                float rad = osg::DegreesToRadians(currTime);

                // zoom scale (0.2 - 1.0)
                float scale = sin(rad * _phaseScale) * 0.4f + 0.6f;
                float scaleR = 1.0f - scale;

                // calculate new texture coordinates
                float s, t;
                s = ((sin(rad * _phaseS) + 1) * 0.5f) * (_img->s() * scaleR);
                t = ((sin(rad * _phaseT) + 1) * 0.5f) * (_img->t() * scaleR);

                // set new texture coordinate array
                osg::Vec2Array* texcoords = (osg::Vec2Array*) _geom->getTexCoordArray(0);
                float w = _img->s() * scale, h = _img->t() * scale;
                (*texcoords)[0].set(s, t+h);
                (*texcoords)[1].set(s, t);
                (*texcoords)[2].set(s+w, t);
                (*texcoords)[3].set(s+w, t+h);

                // record time
                _prevTime = currTime;
            }
        }
    }

private:
    osg::Geometry* _geom;
    osg::Image* _img;

    float _phaseS, _phaseT, _phaseScale;

    double _delay;
    double _prevTime;
};


osg::Node* createRectangle(osg::BoundingBox& bb,
                           const std::string& filename)
{
    // load image
    osg::Image* img = osgDB::readImageFile(filename);
    int w = img->s();
    int h = img->t();
    
    osg::Vec3 top_left( 0, 0, 0 );
    osg::Vec3 bottom_left( w, 0, 0 );
    osg::Vec3 bottom_right( w, 0, h );
    osg::Vec3 top_right( 0, 0, h );
    
    // create geometry
    osg::Geometry* geom = new osg::Geometry;

    osg::Vec3Array* vertices = new osg::Vec3Array(4);
    (*vertices)[0] = top_left;
    (*vertices)[1] = bottom_left;
    (*vertices)[2] = bottom_right;
    (*vertices)[3] = top_right;
    geom->setVertexArray(vertices);
    
    osg::Vec2Array* texcoords = new osg::Vec2Array(4);
    (*texcoords)[0].set(0.0f, 0.0f);
    (*texcoords)[1].set(w, 0.0f);
    (*texcoords)[2].set(w, h);
    (*texcoords)[3].set(0.0f, h);
    geom->setTexCoordArray(0,texcoords);

    osg::Vec3Array* normals = new osg::Vec3Array(1);
    (*normals)[0].set(0.0f,-1.0f,0.0f);
    geom->setNormalArray(normals);
    geom->setNormalBinding(osg::Geometry::BIND_OVERALL);

    osg::Vec4Array* colors = new osg::Vec4Array(1);
    (*colors)[0].set(1.0f,1.0f,1.0f,1.0f);
    geom->setColorArray(colors);
    geom->setColorBinding(osg::Geometry::BIND_OVERALL);

    geom->addPrimitiveSet(new osg::DrawArrays(GL_QUADS, 0, 4));

    // disable display list so our modified tex coordinates show up
    geom->setUseDisplayList(false);

    // setup texture
    osg::TextureRectangle* texture = new osg::TextureRectangle;

    texture->setInternalFormat( GL_FLOAT_RGBA16_NV );
    texture->setImage(img);

    // setup state
    osg::StateSet* state = geom->getOrCreateStateSet();
    state->setTextureAttributeAndModes(0, texture, osg::StateAttribute::ON);

    // turn off lighting 
    state->setMode(GL_LIGHTING, osg::StateAttribute::OFF);

    state->addUniform( exposure.getUniformMin() );
    state->addUniform( exposure.getUniformMax() );
    state->addUniform( exposure.getUniformGrayScale() );
    state->setAttributeAndModes( shader( "readtexture.frag" ),
            osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE );

    // install 'update' callback
    osg::Geode* geode = new osg::Geode;
    geode->addDrawable(geom);
//    geode->setUpdateCallback(new TexturePanCallback(geom, img));
    
    return geode;
}


osg::Geode* createText(const std::string& str,
                       const osg::Vec3& pos)
{
    static std::string font("fonts/arial.ttf");

    osg::Geode* geode = new osg::Geode;

    osgText::Text* text = new osgText::Text;
    geode->addDrawable(text);

    text->setFont(font);
    text->setPosition(pos);
    text->setText(str);

    return geode;
}


osg::Node* createHUD()
{
    osg::Group* group = new osg::Group;

    // turn off lighting and depth test
    osg::StateSet* state = group->getOrCreateStateSet();
    state->setMode(GL_LIGHTING, osg::StateAttribute::OFF);
    state->setMode(GL_DEPTH_TEST, osg::StateAttribute::OFF);

    // add text
    osg::Vec3 pos(120.0f, 800.0f, 0.0f);
    const osg::Vec3 delta(0.0f, -80.0f, 0.0f);

    const char* text[] = {
        "NVIDIA High Dynamic Range Mini-HOWTO",
        "- essentially behaves like TextureRectangle, *except* that:",
        "- tex internal format must be set to GL_FLOAT_RGBA16_NV or similar",
        "- geometry need at last one simple shader to read the texture, like the follow:",
        "      gl_FragColor = texture2DRect( tex0, gl_TexCoord[0].st );",
        "- keyboard mapping:",
        "      - and =, change the exposition",
        "      9 and 0, increase and decrease the dynamic range",
        "      7 and 8, increase and decrease the delta change",
        "      g and G, toogle gray scale",
        NULL
    };
    const char** t = text;
    while (*t) {
        group->addChild(createText(*t++, pos));
        pos += delta;
    }

    // create HUD
    osg::MatrixTransform* modelview_abs = new osg::MatrixTransform;
    modelview_abs->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
    modelview_abs->setMatrix(osg::Matrix::identity());
    modelview_abs->addChild(group);

    osg::Projection* projection = new osg::Projection;
    projection->setMatrix(osg::Matrix::ortho2D(0,1280,0,1024));
    projection->addChild(modelview_abs);

    return projection;
}


osg::Node* createModel(const std::string& filename)
{
    osg::Group* root = new osg::Group;

    if (filename != "X") {
        osg::BoundingBox bb(0.0f,0.0f,0.0f,1.0f,1.0f,1.0f);
        root->addChild(createRectangle(bb, filename)); // XXX
    }

    root->addChild(createHUD());

    return root;
}


class KeyboardEventHandler : public osgGA::GUIEventHandler
{
public:
    
        KeyboardEventHandler() {}
    
        virtual bool handle(const osgGA::GUIEventAdapter& ea,osgGA::GUIActionAdapter&)
        {
            switch(ea.getEventType())
            {
                case(osgGA::GUIEventAdapter::KEYDOWN):
                {
                    switch (ea.getKey())
                    {
                        case '-':
                            exposure.decIndex();
                            break;
                        case '=':
                            exposure.incIndex();
                            break;
                        case '9':
                            exposure.decRange();
                            break;
                        case '0':
                            exposure.incRange();
                            break;
                        case '7':
                            exposure.decDelta();
                            break;
                        case '8':
                            exposure.incDelta();
                            break;
                        case 'g':
                        case 'G':
                            exposure.toogleGrayScale();
                            break;
                        default:
                            return false;
                    }

                    return true;
                }

                default:
                    return false;
            }
        }

        virtual void accept(osgGA::GUIEventHandlerVisitor& v)
        {
            v.visit(*this);
        }
};

int main(int argc, char** argv)
{
    // use an ArgumentParser object to manage the program arguments.
    osg::ArgumentParser arguments(&argc,argv);

    // set up the usage document, in case we need to print out how to use this program.
    arguments.getApplicationUsage()->setDescription(arguments.getApplicationName()+" is a demo which demonstrates use of osg::TextureRectangle.");
    arguments.getApplicationUsage()->setCommandLineUsage(arguments.getApplicationName()+" [options] <image> ...");
    arguments.getApplicationUsage()->addCommandLineOption("-h or --help","Display this information");
   
    // construct the viewer.
    osgProducer::Viewer viewer(arguments);

    // set up the value with sensible default event handlers.
    viewer.setUpViewer(osgProducer::Viewer::STANDARD_SETTINGS);

    // get details on keyboard and mouse bindings used by the viewer.
    viewer.getUsage(*arguments.getApplicationUsage());

    // if user request help write it out to cout.
    if (arguments.read("-h") || arguments.read("--help"))
    {
        arguments.getApplicationUsage()->write(std::cout);
        return 1;
    }

    // any option left unread are converted into errors to write out later.
    arguments.reportRemainingOptionsAsUnrecognized();

    // report any errors if they have occured when parsing the program aguments.
    if (arguments.errors())
    {
        arguments.writeErrorMessages(std::cout);
        return 1;
    }

    // create a model from the images.
    osg::Node* rootNode = createModel((arguments.argc() > 1 ? arguments[1] : "Images/lz.rgb"));

    KeyboardEventHandler* keh = new KeyboardEventHandler();
    viewer.getEventHandlerList().push_front( keh );
    // add model to viewer.
    viewer.setSceneData( rootNode );

    // create the windows and run the threads.
    viewer.realize();

    while ( !viewer.done() )
    {
        // wait for all cull and draw threads to complete.
        viewer.sync();

        // update the scene by traversing it with the the update visitor which will
        // call all node update callbacks and animations.
        viewer.update();

        // fire off the cull and draw traversals of the scene.
        viewer.frame();
    }

    // wait for all cull and draw threads to complete before exit.
    viewer.sync();
    
    return 0;
}
