#!/bin/sh

echo $0 use PFSTools to extract six image from a HDR Shop vertical cross
echo cube map. This images can be used as cube map in OpenGL.
echo You can found PFSTools here: http://www.mpi-sb.mpg.de/resources/pfstools/
echo

[ ! $1 ] && echo "usage: $0 filename.hdr base" && echo && exit
[ ! $2 ] && echo "usage: $0 filename.hdr base" && echo && exit

ext=".hdr"
file=$1
base=`basename $file $ext`"-"

p1=$2
p2=$(($2 * 2))
p3=$(($2 * 3))

l="-l $p1"
r="-r $p1"

t=""
b="-b $p3"
out="posz" # top
#pfsin $file| pfscut $l $r $t $b|pfsrotate -r|pfsout $base$out$ext
pfsin $file| pfscut $l $r $t $b|pfsout $base$out$ext

t="-t $p1"
b="-b $p2"
out="posy" # hear
pfsin $file| pfscut $l $r $t $b|pfsout $base$out$ext

t="-t $p2"
b="-b $p1"
out="negz" # botton
#pfsin $file| pfscut $l $r $t $b|pfsrotate -r |pfsflip -h -v|pfsout $base$out$ext
#pfsin $file| pfscut $l $r $t $b|pfsout $base$out$ext
pfsin $file| pfscut $l $r $t $b|pfsflip -h -v|pfsout $base$out$ext

t="-t $p3"
b=""
out="negy" # front
#pfsin $file| pfscut $l $r $t $b|pfsflip -h -v|pfsout $base$out$ext
pfsin $file| pfscut $l $r $t $b|pfsout $base$out$ext

t="-t $p1"
b="-b $p2"

l=""
r="-r $p2"
out="negx" # right
#pfsin $file| pfscut $l $r $t $b|pfsout $base$out$ext
pfsin $file| pfscut $l $r $t $b|pfsrotate -r |pfsflip -h -v|pfsout $base$out$ext

l="-l $p2"
r=""
out="posx" # left
#pfsin $file| pfscut $l $r $t $b|pfsout $base$out$ext
pfsin $file| pfscut $l $r $t $b|pfsrotate -r |pfsout $base$out$ext
