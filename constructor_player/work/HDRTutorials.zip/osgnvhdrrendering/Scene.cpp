
#include <osg/TexEnv>
#include <osg/TexGen>
#include <osg/TexMat>
#include <osg/TextureCubeMap>
#include <osg/Depth>
#include <osg/ShapeDrawable>
#include <osgDB/ReadFile>
#include <osgUtil/Optimizer>
#include <osgUtil/SmoothingVisitor>

#include "Scene"
#include "RenderToTexture"
#include "ImageCubeMap"

#include <iostream>

osg::TextureCubeMap* readCubeMap( const std::string filename )
{
    osg::ref_ptr<osgDB::ReaderWriter::Options> options;
#ifndef LDR
    options = new osgDB::ReaderWriter::Options( "RAW" );
#endif
    ImageCubeMap image;
    if ( !image.readImageFile( filename, options.get() ) ) return NULL;
    osg::TextureCubeMap* cubemap = new osg::TextureCubeMap;
    image.setIntoTexture( cubemap );

    cubemap->setWrap(osg::Texture::WRAP_S, osg::Texture::CLAMP_TO_EDGE);
    cubemap->setWrap(osg::Texture::WRAP_T, osg::Texture::CLAMP_TO_EDGE);
    cubemap->setWrap(osg::Texture::WRAP_R, osg::Texture::CLAMP_TO_EDGE);
#ifndef LDR
    cubemap->setFilter(osg::Texture::MIN_FILTER, osg::Texture::NEAREST);
    cubemap->setFilter(osg::Texture::MAG_FILTER, osg::Texture::NEAREST);
#else
    cubemap->setFilter(osg::Texture::MIN_FILTER, osg::Texture::LINEAR_MIPMAP_LINEAR);
    cubemap->setFilter(osg::Texture::MAG_FILTER, osg::Texture::LINEAR);
#endif
    return cubemap;
}

// Update texture matrix for cubemaps
struct TexMatCallback : public osg::NodeCallback
{
public:

    TexMatCallback(osg::TexMat& tm) :
        _texMat(tm)
    {
    }

    virtual void operator()(osg::Node* node, osg::NodeVisitor* nv)
    {
        osgUtil::CullVisitor* cv = dynamic_cast<osgUtil::CullVisitor*>(nv);
        if (cv)
        {
            const osg::Matrix& MV = cv->getModelViewMatrix();
//            const osg::Matrix R =
//                osg::Matrix::rotate( osg::DegreesToRadians(-00.0f), 0.0f,0.0f,1.0f)*
//                osg::Matrix::rotate( osg::DegreesToRadians(00.0f), 1.0f,0.0f,0.0f);

            osg::Quat q;
            MV.get(q);
            const osg::Matrix C = osg::Matrix::rotate( q.inverse() );

//            _texMat.setMatrix( C*R );
            _texMat.setMatrix( C );
        }

        traverse(node,nv);
    }

    osg::TexMat& _texMat;
};


class MoveEarthySkyWithEyePointTransform : public osg::Transform
{
public:
    /** Get the transformation matrix which moves from local coords to world coords.*/
    virtual bool computeLocalToWorldMatrix(osg::Matrix& matrix,osg::NodeVisitor* nv) const 
    {
        osgUtil::CullVisitor* cv = dynamic_cast<osgUtil::CullVisitor*>(nv);
        if (cv)
        {
            osg::Vec3 eyePointLocal = cv->getEyeLocal();
            matrix.preMult(osg::Matrix::translate(eyePointLocal));
        }
        return true;
    }

    /** Get the transformation matrix which moves from world coords to local coords.*/
    virtual bool computeWorldToLocalMatrix(osg::Matrix& matrix,osg::NodeVisitor* nv) const
    {
        osgUtil::CullVisitor* cv = dynamic_cast<osgUtil::CullVisitor*>(nv);
        if (cv)
        {
            osg::Vec3 eyePointLocal = cv->getEyeLocal();
            matrix.postMult(osg::Matrix::translate(-eyePointLocal));
        }
        return true;
    }
};

osg::Node* createSkyBox( osg::Texture* skymap )
{

    osg::StateSet* stateset = new osg::StateSet();

    osg::TexEnv* te = new osg::TexEnv;
    te->setMode(osg::TexEnv::REPLACE);
    stateset->setTextureAttributeAndModes(0, te, osg::StateAttribute::ON);

    osg::TexGen *tg = new osg::TexGen;
    tg->setMode(osg::TexGen::NORMAL_MAP);
    stateset->setTextureAttributeAndModes(0, tg, osg::StateAttribute::ON);

    osg::TexMat *tm = new osg::TexMat;
    stateset->setTextureAttribute(0, tm);

    stateset->setTextureAttributeAndModes(0, skymap, osg::StateAttribute::ON);

    stateset->setMode( GL_LIGHTING, osg::StateAttribute::OFF );
    stateset->setMode( GL_CULL_FACE, osg::StateAttribute::OFF );

    // clear the depth to the far plane.
    osg::Depth* depth = new osg::Depth;
    depth->setFunction(osg::Depth::ALWAYS);
    depth->setRange(1.0,1.0);   
    stateset->setAttributeAndModes(depth, osg::StateAttribute::ON );

    stateset->setRenderBinDetails(-1,"RenderBin");

    osg::Drawable* drawable = new osg::ShapeDrawable(new osg::Sphere(osg::Vec3(0.0f,0.0f,0.0f),1));

    osg::Geode* geode = new osg::Geode;
    geode->setCullingActive(false);
    geode->setStateSet( stateset );
    geode->addDrawable(drawable);


    osg::Transform* transform = new MoveEarthySkyWithEyePointTransform;
    transform->setCullingActive(false);
    transform->addChild(geode);

    osg::ClearNode* clearNode = new osg::ClearNode;
//  clearNode->setRequiresClear(false);
    clearNode->setCullCallback(new TexMatCallback(*tm));
    clearNode->addChild(transform);

    return clearNode;
}

osg::Node * setupSkyBox( osg::Texture * cubemap )
{
    osg::Node * cube = createSkyBox( cubemap );

    cube->getOrCreateStateSet()->setAttributeAndModes( shader( "cube" ),
            osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE );

    return cube;
}

osg::Node * loadModel( std::string filename, osg::Texture * cubemap )
{
    osg::Node * model = osgDB::readNodeFile( filename );
    if (!model)
    {
        const float radius = 1.0f;
        osg::Geode* geode = new osg::Geode;
        geode->addDrawable(new osg::ShapeDrawable(new osg::Sphere(osg::Vec3(0.0f,0.0f,0.0f),radius)));
        model = geode;
    }

    // run optimization over the scene graph
    osgUtil::Optimizer optimzer;
    optimzer.optimize(model);

    // create normals.    
    osgUtil::SmoothingVisitor smoother;
    model->accept(smoother);


    osg::StateSet* stateset = model->getOrCreateStateSet();
    
    stateset->setAttributeAndModes( shader( "std" ),
            osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE );
    
    stateset->setTextureAttributeAndModes(0, cubemap, osg::StateAttribute::OVERRIDE);
    
    return model;
}

osg::Node * loadScene( std::string cubemap_filename,
        std::string scene_filename )
{

/*
    scene_filename = "dumptruck.osg";
    scene_filename = "cow.osg";
    scene_filename = "";
    scene_filename = "axes.osg";
*/
/*
    cubemap_filename = "../data/beach_cross.hdr";
    cubemap_filename = "../data/building_cross.hdr";
    cubemap_filename = "../data/campus_cross.hdr";
    cubemap_filename = "../data/galileo_cross.hdr";
    cubemap_filename = "../data/grace_cross.hdr";
    cubemap_filename = "../data/kitchen_cross.hdr";
    cubemap_filename = "../data/rnl_cross.hdr";
    cubemap_filename = "../data/uffizi_cross.hdr";
    cubemap_filename = "../data/stpeters_cross.hdr";
 */

    osg::Texture* cubemap = readCubeMap( cubemap_filename );
    osg::Group * root = new osg::Group();

    // At last one shader is need to render with NVIDIA float extensions :-(
    root->addChild( setupSkyBox( cubemap ) );
    root->addChild( loadModel( scene_filename, cubemap ) );

    return root;
}
