
#include <osg/Geometry>
#include <osg/Geode>

#include "RenderToTexture"

#include <iostream>

osg::Shader * setDefines( osg::Shader * shader )
{
    std::string source = shader->getShaderSource();
#ifdef LDR
    source = "#define LDR\n" + source;
#endif
    shader->setShaderSource( source );
    return shader;
}

osg::Program* shader( std::string prefix )
{
    osg::Program* ProgramObject = new osg::Program;

    osg::Shader* FragmentObject =
      new osg::Shader( osg::Shader::FRAGMENT );
    osg::Shader* VertexObject =
      new osg::Shader( osg::Shader::VERTEX );

    bool frag = FragmentObject->loadShaderSourceFromFile( prefix + ".frag" );
    bool vert = VertexObject->loadShaderSourceFromFile( prefix + ".vert" );

    if (frag) ProgramObject->addShader( setDefines( FragmentObject ) );
    if (vert) ProgramObject->addShader( setDefines( VertexObject ) );

    return ProgramObject;
}

GLfloat * copyFloatData( int x, int y, int w, int h, int c, osg::Image * image,
        bool rotate )
{
    if (!image) return NULL;

    GLfloat * data = new GLfloat[w * h * c];

    for ( int i = 0; i < w * h * c; ++i )
    {
        //if ( i % w/4 == 0 )
        if ( i % c == 0 )
            data[i] = 1.0;
    }

    GLfloat * d = data;
    int ib = rotate ? x : y;
    int ie = rotate ? x+w : y+h;
    int jb = rotate ? y : x;
    int je = rotate ? y+h : x+w;

    for ( int i = ib; i < ie; ++i )
    for ( int j = jb; j < je; ++j )
    {
        GLfloat * value;
        if ( rotate )
            value = (GLfloat *) image->data(i, j);
        else
            value = (GLfloat *) image->data(j, i);
        
        for ( int k = 0; k < c; ++k )
        {
            *d = value[k];
            d++;
        }
    }

    return data;
}

osg::Image * createFloatImage( int w, int h, int c, GLfloat * data )
{
    GLenum format, internalFormat;
    switch (c)
    {
        case 1:
            format = GL_LUMINANCE;
            internalFormat = GL_LUMINANCE8;
            break;
        case 3:
            format = GL_RGB;
            internalFormat = GL_RGB8;
            break;
        case 4:
            format = GL_RGBA;
            internalFormat = GL_RGBA8;
            break;
        default:
            return NULL;
    }

    if (!data)
    {
        data = new GLfloat[w * h * c];

        for ( int i = 0; i < w * h * c; ++i )
        {
            //if ( i % w/4 == 0 )
                data[i] = 1.0;
        }
    }

    osg::Image *image = new osg::Image;
    image->setImage(  w, h, 1, internalFormat,
                    format, GL_FLOAT, (unsigned char *) data,
                    osg::Image::USE_NEW_DELETE );

    return image;
};

osg::TextureRectangle * createFloatTexture( unsigned int w, unsigned int h )
{
    osg::TextureRectangle * tex = new osg::TextureRectangle;
    
    tex->setInternalFormat(GL_FLOAT_RGBA16_NV);
    //tex->setTextureSize(w, h);
    tex->setImage( createFloatImage( w, h, 3 ) );

    return tex;
}

// This function builds a textured quad
osg::Node * createQuad(osg::TextureRectangle *tex)
{
    unsigned int w = tex->getImage()->s();
    unsigned int h = tex->getImage()->t();

    osg::Geometry *geo = new osg::Geometry;
    
    osg::Vec3Array *vx = new osg::Vec3Array;
    vx->push_back(osg::Vec3( 1.0, 0, -1.0));
    vx->push_back(osg::Vec3(-1.0, 0, -1.0));
    vx->push_back(osg::Vec3(-1.0, 0,  1.0));
    vx->push_back(osg::Vec3( 1.0, 0,  1.0));
    geo->setVertexArray(vx);
    
    osg::Vec3Array *nx = new osg::Vec3Array;
    nx->push_back(osg::Vec3(0, -1, 0));
    geo->setNormalArray(nx);
    geo->setNormalBinding(osg::Geometry::BIND_OVERALL);
    
    // This textures coordenates isn't normalized due
    // the use of TextureRectangles
    osg::Vec2Array *tx = new osg::Vec2Array;
    tx->push_back(osg::Vec2(0, 0));
    tx->push_back(osg::Vec2(w, 0));
    tx->push_back(osg::Vec2(w, h));
    tx->push_back(osg::Vec2(0, h));
    geo->setTexCoordArray(0, tx);

    geo->addPrimitiveSet(new osg::DrawArrays(GL_QUADS, 0, 4));
    geo->getOrCreateStateSet()->setTextureAttributeAndModes(0, tex);

    geo->getStateSet()->setAttributeAndModes( shader( "readback" ),
            osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE );

    osg::Geode *geode = new osg::Geode;
    geode->addDrawable(geo);
    return geode;
};

osg::CameraNode * createRTTCamera( osg::TextureRectangle * tex )
{
    unsigned int w = tex->getImage()->s();
    unsigned int h = tex->getImage()->t();

    osg::CameraNode * camera = new osg::CameraNode;
    camera->setClearColor(osg::Vec4(0.1f,0.1f,0.3f,1.0f));
    camera->setClearMask(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    camera->setViewport(0, 0, w, h);
    camera->getOrCreateStateSet()->setAttribute(camera->getViewport());
    
    // set the camera to render before the main camera.
    camera->setRenderOrder(osg::CameraNode::PRE_RENDER);
    
    // set view
    camera->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
    //camera->setViewMatrixAsLookAt(bs.center()+osg::Vec3(0.0f,2.0f,0.0f)*bs.radius(),bs.center(),osg::Vec3(0.0f,0.0f,1.0f));

    // tell the camera to use OpenGL frame buffer object where supported.
    camera->setRenderTargetImplmentation(osg::CameraNode::FRAME_BUFFER_OBJECT);
    
    // attach the texture and use it as the color buffer.
    camera->attach(osg::CameraNode::COLOR_BUFFER, tex);

    return camera;
}

void addRTTScene( osg::CameraNode * camera, osg::Node * scene )
{
    const osg::BoundingSphere& bs = scene->getBound();

    float znear = 1.0f*bs.radius();
    float zfar  = 3.0f*bs.radius();

    // 2:1 aspect ratio as per flag geomtry below.
    float proj_top   = 0.5f*znear;
    float proj_right = 0.5f*znear;

    znear *= 0.9f;
    zfar *= 1.1f;

    // set up projection.
    camera->setProjectionMatrixAsFrustum(-proj_right,proj_right,-proj_top,proj_top,znear,zfar);

    // attach the scene
    camera->addChild( scene );
}

osgGA::TrackballManipulator * createManipulator( osg::Node * scene )
{
    osgGA::TrackballManipulator * tbm = new osgGA::TrackballManipulator();
    tbm->setNode( scene );
    tbm->home( 0.0 );
    return tbm;
}

