
#include <osg/GL>
#include <osg/Group>
#include <osg/Geometry>
#include <osg/Geode>
#include <osg/Viewport>
#include <osg/MatrixTransform>
#include <osg/FrameBufferObject>
#include <osg/TextureRectangle>
#include <osgProducer/Viewer>
#include <osgDB/ReadFile>

#include "Scene"
#include "RenderToTexture"

class RenderToTexture
{
private:
    unsigned int width;
    unsigned int height;
    osg::ref_ptr<osg::CameraNode> camera;
    osg::ref_ptr<osgGA::TrackballManipulator> tbm;

    osg::Group * createRTTScene( osg::Node * scene )
    {
        // create and configure the texture that we're going
        // to use as target for render-to-texture
        osg::TextureRectangle * tex = createFloatTexture( width, height );

        camera = createRTTCamera( tex );
        addRTTScene( camera.get(), scene );

        osg::Group * root = new osg::Group;
        // attach the camera to the main scene graph.    
        root->addChild( camera.get() );

        // now create a simple quad that will be rendered
        // in the main framebuffers. The quad's texture
        // will be the content of the FBO's color buffer
        root->addChild( createQuad(tex) );

        return root;
    }
    
public:

    RenderToTexture( osgProducer::Viewer & viewer, osg::Node * scene )
        : width( 0 ), height( 0 )
    {
        setupWindow( viewer, scene );
        tbm = createManipulator( scene );
        viewer.getEventHandlerList().push_front( tbm.get() );
    }
    
    void setupWindow( osgProducer::Viewer & viewer, osg::Node * scene )
    {
        int x, y;
        unsigned int w, h;
        Producer::Camera * camera = viewer.getCamera( 0 );
        camera->getRenderSurface()->getWindowRectangle( x, y, w, h );

        if (width != w || height != h)
        {
            width = w;
            height = h;
            camera->getLens()->setOrtho( -1.0, 1.0, -1.0, 1.0, 0.0, 0.0 );
        
            viewer.setSceneData( createRTTScene( scene ) );
        }
    }

    void updateViewMatrix()
    {
        camera->setViewMatrix( tbm->getInverseMatrix() );
    }
};

int usage( std::string filename )
{
    std::cerr
        << "usage: " << filename << " something_cross.hdr [something.osg]"
        << std::endl;
    return -1;
}

int main( int argc, char * argv[] )
{
    std::string cubemap_filename, scene_filename;

    if ( argc < 2 )
        return usage( argv[0] );

    if ( argc > 1 )
        cubemap_filename = argv[1];
    if ( argc > 2 )
        scene_filename = argv[2];

    osg::ref_ptr<osg::Node> scene = loadScene( cubemap_filename, scene_filename );
    if (!scene) return -1;

    osgProducer::Viewer viewer;
    viewer.setUpViewer();
    viewer.realize();

    RenderToTexture rtt( viewer, scene.get() );

    while (!viewer.done())
    {
        viewer.sync();
        // Uncomment the follow line to automatically resize the RTT target
        // I don't know why, but it eat a lot of fps.
        //rtt.setupWindow( viewer, scene.get() )
        rtt.updateViewMatrix();
        viewer.update();
        viewer.frame();
    }

    viewer.sync();
    viewer.cleanup_frame();
    viewer.sync();
    return 0;
}
