
#include <iostream>
#include <sstream>

#include "Scene"

osg::TextureRectangle* createTexture( std::string filename )
{
    osg::Image * image = osgDB::readImageFile( filename );

    if ( !image )
        return NULL;
    
    // setup texture
    osg::TextureRectangle* texture = new osg::TextureRectangle;

    texture->setInternalFormat( GL_FLOAT_RGBA16_NV );
    texture->setImage( image );

    return texture;
}

osg::TextureRectangle* createSimpleHDRTexture()
{
    const int s = 512;
    const int c = 3;
    float * cols = new float[s * s * c];

    float * i = cols;
    for ( int x = 0; x < s; ++x )
        for ( int y = 0; y < s; ++y )
        {
            float v =  ((float) y / (float) s ) * 2;
            *(i++) = v;
            *(i++) = v;
            *(i++) = v;
            //cols[ s * x + y ] =
        }

        
    // create the osg::Image to fill in.
    osg::Image *img = new osg::Image;

    int internalFormat = GL_FLOAT_RGBA16_NV;
    int pixelFormat = GL_RGB;
    int dataType = GL_FLOAT;

    img->setFileName("SimpleHDRTexture");
    img->setImage(  s, s, 1,
                    internalFormat,
                    pixelFormat,
                    dataType,
                    (unsigned char*) cols,
                    osg::Image::USE_NEW_DELETE);
    // setup texture
    osg::TextureRectangle* texture = new osg::TextureRectangle;

//    texture->setInternalFormat( GL_FLOAT_RGBA16_NV );
    texture->setImage( img );

    return texture;
}

osg::Program * createShader( std::string filename )
{
    
    osg::Shader* VertexObject =
      new osg::Shader( osg::Shader::VERTEX );
    bool vert = VertexObject->loadShaderSourceFromFile( filename + ".vert" );
            
    osg::Shader* FragmentObject =
      new osg::Shader( osg::Shader::FRAGMENT );
    bool frag = FragmentObject->loadShaderSourceFromFile( filename + ".frag" );
            
    osg::Program* ProgramObject = new osg::Program;
    if (vert) ProgramObject->addShader( VertexObject );
    if (frag) ProgramObject->addShader( FragmentObject );

    return ProgramObject;
};

osg::Node * createGeometry( std::string filename )
{
    return osgDB::readNodeFile( filename ); 
}

osg::Node* createSphere()
{
    osg::Geode * geode = new osg::Geode();
    geode->addDrawable( new osg::ShapeDrawable(
                new osg::Sphere(osg::Vec3(0.0f, 0.0f, 0.0f), 0.15f) ) );
    return geode;
}

osg::Node* createRectangle()
{
    osg::Vec3 top_left( 0, 0, 0 );
    osg::Vec3 bottom_left( 1, 0, 0 );
    osg::Vec3 bottom_right( 1, 0, 1 );
    osg::Vec3 top_right( 0, 0, 1 );
    
    // create geometry
    osg::Geometry* geom = new osg::Geometry;

    osg::Vec3Array* vertices = new osg::Vec3Array(4);
    (*vertices)[0] = top_left;
    (*vertices)[1] = bottom_left;
    (*vertices)[2] = bottom_right;
    (*vertices)[3] = top_right;
    geom->setVertexArray(vertices);
    
    osg::Vec2Array* texcoords = new osg::Vec2Array(4);
    (*texcoords)[0].set(0.0f, 0.0f);
    (*texcoords)[1].set(1.0f, 0.0f);
    (*texcoords)[2].set(1.0f, 1.0f);
    (*texcoords)[3].set(0.0f, 1.0f);
    geom->setTexCoordArray(0,texcoords);

    osg::Vec3Array* normals = new osg::Vec3Array(1);
    (*normals)[0].set(0.0f,-1.0f,0.0f);
    geom->setNormalArray(normals);
    geom->setNormalBinding(osg::Geometry::BIND_OVERALL);

    osg::Vec4Array* colors = new osg::Vec4Array(1);
    (*colors)[0].set(1.0f,1.0f,1.0f,1.0f);
    geom->setColorArray(colors);
    geom->setColorBinding(osg::Geometry::BIND_OVERALL);

    geom->addPrimitiveSet(new osg::DrawArrays(GL_QUADS, 0, 4));

    // disable display list so our modified tex coordinates show up
    geom->setUseDisplayList(false);

    // install 'update' callback
    osg::Geode* geode = new osg::Geode;
    geode->addDrawable(geom);
    

    return geode;
}

osg::Uniform* Scene::getUniformWidth()
{
    return new osg::Uniform( "width", (float) getTex()->getImage()->s() );
}

osg::Uniform* Scene::getUniformHeight()
{
    return new osg::Uniform( "height", (float) getTex()->getImage()->t() );
}

osg::TextureRectangle* Scene::getTex()
{
    return tex.front().first.get();
}

osg::Node* Scene::setupGeometry( osg::Node* geom )
{
    // setup state
    osg::StateSet* state = geom->getOrCreateStateSet();

    state->setTextureAttributeAndModes( 0, getTex(), osg::StateAttribute::ON );

    // turn off lighting 
    state->setMode( GL_LIGHTING, osg::StateAttribute::OFF );

    state->addUniform( getUniformWidth() );
    state->addUniform( getUniformHeight() );
    state->addUniform( getExposure().getUniformMin() );
    state->addUniform( getExposure().getUniformMax() );
    state->addUniform( getExposure().getUniformGrayScale() );

    state->setAttributeAndModes( createShader( "readtexture" ),
            osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE );

    return geom;
}

void Scene::setupScene()
{
    for ( NodeList::iterator it = geom.begin(); it != geom.end(); it++ )
        setupGeometry( (*it).get() );
}

Scene::Scene()
{
    char buff[256];
    std::string opt;

    std::ifstream it("texture.conf");
    if ( it.is_open() == true )
    {
        while ( !it.eof() )
        {
            it.getline( buff, 256 );
            if ( buff[0] == '#' )
            {
                std::cerr << "Ignoring line: " << buff << std::endl;
                continue;
            }
            std::istringstream iss( buff );
            iss >> opt;
            
            std::cerr << "Loading texture file " << opt << "...";
            osg::TextureRectangle * texture = createTexture( opt );
            if ( texture )
            {
                Exposure* exp = new Exposure();
                exp->in( iss );
                tex.push_back( std::make_pair( texture, exp ) );
                std::cerr << "DONE" << std::endl;
            } else
                std::cerr << "FAIL (file not found)" << std::endl;
        }
        it.close();
    }

    tex.push_back( std::make_pair( createSimpleHDRTexture(), new Exposure() ) );

    std::ifstream ig("geometry.conf");
    if ( ig.is_open() == true )
    {
        while (ig >> opt)
        {
            std::cerr << "Loading geometry file " << opt << "...";
            osg::Node * geometry = createGeometry( opt );
            if ( geometry )
            {
                geom.push_back( geometry );
                std::cerr << "DONE" << std::endl;
            } else
                std::cerr << "FAIL (file not found)" << std::endl;
        }
        ig.close();
    }

    geom.push_back( createSphere() );
    geom.push_back( createRectangle() );

    setupScene();

    root = new osg::Group;
    root->addChild( geom.front().get() );
}

void Scene::saveTextureConf()
{
    std::cerr << "Saving texture configuration...";
    std::ofstream ot("texture.conf");
    ot << "# filename index range delta gray" << std::endl;
    for ( Scene::TexList::iterator it = tex.begin(); it != tex.end(); it++ )
    {
        if ( "SimpleHDRTexture" == (*it).first->getImage()->getFileName() ) continue;
        ot << (*it).first->getImage()->getFileName() << " ";
        (*it).second->out( ot );
        ot << std::endl;
    }
    std::cerr << "DONE" << std::endl;
}

void Scene::nextGeometry()
{
    geom.push_back( geom.front() );
    geom.pop_front();
    root->replaceChild( geom.back().get(), geom.front().get() );
}

void Scene::prevGeometry()
{
    root->replaceChild( geom.front().get(), geom.back().get() );
    geom.push_front( geom.back() );
    geom.pop_back();
}

void Scene::nextTexture()
{
    tex.push_back( tex.front() );
    tex.pop_front();
    setupScene();
}

void Scene::prevTexture()
{
    tex.push_front( tex.back() );
    tex.pop_back();
    setupScene();
}

osg::Group* Scene::getRoot()
{
    return root.get();
}

Exposure & Scene::getExposure()
{
    return *tex.front().second;
}
