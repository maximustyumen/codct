
#include "Exposure"

void Exposure::update( bool print )
{
    float min, max;
    min = index - ( range / 2.0 );
    max = index + ( range / 2.0 );

    if ( print )
        fprintf(stderr, "Exposure %f, Range %f, Delta %f, Dynamic Range (%f, %f)\n",
            index, range, delta, min, max );

    umin->set( min );
    umax->set( max );
}

Exposure::Exposure()
    : index( 0.5 ), range( 1.0 ), delta( 0.1 ), gray( false )
{
    umin = new osg::Uniform( "min", 0.0f );
    umax = new osg::Uniform( "max", 0.0f );
    ugray = new osg::Uniform( "gray", gray );
    update( false );
}

void Exposure::out( std::ostream & os )
{
    os << index << " " << range << " " << delta << " " << gray;
}

void Exposure::in( std::istream & is )
{
    is >> index >> range >> delta >> gray;
    update( false );
}

osg::Uniform * Exposure::getUniformMin()
{
    return umin.get();
}
osg::Uniform * Exposure::getUniformMax()
{
    return umax.get();
}
osg::Uniform * Exposure::getUniformGrayScale()
{
    return ugray.get();
}

void Exposure::incIndex()
{
    index += delta;
    update();
}
void Exposure::decIndex()
{
    index -= delta;
    update();
}
void Exposure::incRange()
{
    range += delta;
    update();
}
void Exposure::decRange()
{
    range -= delta;
    range = range < 0.0 ? 0.0 : range;
    update();
}
void Exposure::incDelta()
{
    delta += 0.01;
    update();
}
void Exposure::decDelta()
{
    delta -= 0.01;
    delta = delta < 0.0 ? 0.0 : delta;
    update();
}
void Exposure::toogleGrayScale()
{
    gray = !gray;
    ugray->set( gray );
}
