// -*-c++-*-

/*
 * demonstrates usage High Dynamic Range on NVIDIA FX hardware and up
 *
 * - essentially behaves like TextureRectangle, *except* that:
 * - tex internal format must be set to GL_FLOAT_RGBA16_NV or similar
 * - geometry need at last one simple shader to read the texture, like the follow:
 *       gl_FragColor = texture2DRect( tex0, gl_TexCoord[0].st );
 * - keyboard mapping:
 *       - and =, change the exposition
 *       9 and 0, increase and decrease the dynamic range
 *       7 and 8, increase and decrease the delta change
 *       g and G, toogle gray scale
 *
 */

#include <osg/Notify>
#include <osg/Geometry>
#include <osg/Geode>
#include <osg/Group>
#include <osg/Projection>
#include <osg/MatrixTransform>
#include <osgText/Text>
#include <osgDB/Registry>
#include <osgProducer/Viewer>

#include "Scene"

Scene scene;

osg::Geode* createText(const std::string& str,
                       const osg::Vec3& pos)
{
    static std::string font("fonts/arial.ttf");

    osg::Geode* geode = new osg::Geode;

    osgText::Text* text = new osgText::Text;
    geode->addDrawable(text);

    text->setFont(font);
    text->setPosition(pos);
    text->setText(str);

    return geode;
}


osg::Node* createHUD()
{
    osg::Group* group = new osg::Group;

    // turn off lighting and depth test
    osg::StateSet* state = group->getOrCreateStateSet();
    state->setMode(GL_LIGHTING, osg::StateAttribute::OFF);
    state->setMode(GL_DEPTH_TEST, osg::StateAttribute::OFF);

    // add text
    osg::Vec3 pos(120.0f, 950.0f, 0.0f);
    const osg::Vec3 delta(0.0f, -80.0f, 0.0f);

    const char* text[] = {
        "NVIDIA High Dynamic Range Mini-HOWTO",
        "- essentially behaves like TextureRectangle, *except* that:",
        "- tex internal format must be set to GL_FLOAT_RGBA16_NV or similar",
        "- geometry need at last one simple shader to read the texture, like the follow:",
        "      gl_FragColor = texture2DRect( tex0, gl_TexCoord[0].st );",
        "- keyboard mapping:",
        "      - and =, change the exposition",
        "      9 and 0, increase and decrease the dynamic range",
        "      7 and 8, increase and decrease the delta change",
        "      g and G, toogle gray scale",
        "      m and M, next/previous model or n and N, next/previous texture",
        "      t and T, save texture list and exposure",
        NULL
    };
    const char** t = text;
    while (*t) {
        group->addChild(createText(*t++, pos));
        pos += delta;
    }

    // create HUD
    osg::MatrixTransform* modelview_abs = new osg::MatrixTransform;
    modelview_abs->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
    modelview_abs->setMatrix(osg::Matrix::identity());
    modelview_abs->addChild(group);

    osg::Projection* projection = new osg::Projection;
    projection->setMatrix(osg::Matrix::ortho2D(0,1280,0,1024));
    projection->addChild(modelview_abs);

    return projection;
}


osg::Node* createModel()
{
    osg::Group* root = new osg::Group;

    root->addChild( scene.getRoot() );
    root->addChild( createHUD() );

    return root;
}


class KeyboardEventHandler : public osgGA::GUIEventHandler
{
    void computeHome( const osgGA::GUIEventAdapter& ea )
    {
        osgProducer::EventAdapter * pea =
            (osgProducer::EventAdapter *) &ea;
        pea->setKey( ' ' );
    }
public:
    
        KeyboardEventHandler() {}
    
        virtual bool handle(const osgGA::GUIEventAdapter& ea,osgGA::GUIActionAdapter&)
        {
            switch ( ea.getEventType() )
            {
                case ( osgGA::GUIEventAdapter::KEYDOWN ):
                {
                    Exposure & exposure = scene.getExposure();
                    switch ( ea.getKey() )
                    {
                        case '-': exposure.decIndex(); break;
                        case '=': exposure.incIndex(); break;
                        case '9': exposure.decRange(); break;
                        case '0': exposure.incRange(); break;
                        case '7': exposure.decDelta(); break;
                        case '8': exposure.incDelta(); break;
                        case 'g':
                        case 'G': exposure.toogleGrayScale(); break;
                        case 'm':
                            scene.nextGeometry();
                            computeHome( ea );
                            return false;
                            break;
                        case 'M': 
                            scene.prevGeometry();
                            computeHome( ea );
                            return false;
                            break;
                        case 'n': scene.nextTexture(); break;
                        case 'N': scene.prevTexture(); break;
                        case 't':
                        case 'T': scene.saveTextureConf(); break;
                        default: return false;
                    }
                    return true;
                }
                default: return false;
            }
        }

        virtual void accept(osgGA::GUIEventHandlerVisitor& v)
        {
            v.visit(*this);
        }
};

int main(int argc, char** argv)
{
    // use an ArgumentParser object to manage the program arguments.
    osg::ArgumentParser arguments(&argc,argv);

    // set up the usage document, in case we need to print out how to use this program.
    arguments.getApplicationUsage()->setDescription(arguments.getApplicationName()+" is a demo which demonstrates use of osg::TextureRectangle.");
    arguments.getApplicationUsage()->setCommandLineUsage(arguments.getApplicationName()+" [options] <image> ...");
    arguments.getApplicationUsage()->addCommandLineOption("-h or --help","Display this information");
   
    // construct the viewer.
    osgProducer::Viewer viewer(arguments);

    // set up the value with sensible default event handlers.
    viewer.setUpViewer(osgProducer::Viewer::STANDARD_SETTINGS);

    // get details on keyboard and mouse bindings used by the viewer.
    viewer.getUsage(*arguments.getApplicationUsage());

    // if user request help write it out to cout.
    if (arguments.read("-h") || arguments.read("--help"))
    {
        arguments.getApplicationUsage()->write(std::cout);
        return 1;
    }

    // any option left unread are converted into errors to write out later.
    arguments.reportRemainingOptionsAsUnrecognized();

    // report any errors if they have occured when parsing the program aguments.
    if (arguments.errors())
    {
        arguments.writeErrorMessages(std::cout);
        return 1;
    }

    // create a model from the images.
    osg::Node* rootNode = createModel();

    KeyboardEventHandler* keh = new KeyboardEventHandler();
    viewer.getEventHandlerList().push_front( keh );
    // add model to viewer.
    viewer.setSceneData( rootNode );

    // create the windows and run the threads.
    viewer.realize();

    while ( !viewer.done() )
    {
        // wait for all cull and draw threads to complete.
        viewer.sync();

        // update the scene by traversing it with the the update visitor which will
        // call all node update callbacks and animations.
        viewer.update();

        // fire off the cull and draw traversals of the scene.
        viewer.frame();
    }

    // wait for all cull and draw threads to complete before exit.
    viewer.sync();
    
    return 0;
}
